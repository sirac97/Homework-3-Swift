//
//  DetailVC.swift
//  SiracBoranHW3
//
//  Created by CTIS Student on 14.12.2021.
//  Copyright © 2021 CTIS. All rights reserved.
//

import UIKit

class DetailVC: UIViewController {
    
    
    @IBOutlet weak var myTitle: UINavigationItem!
    @IBOutlet weak var myImage: UIImageView!
    @IBOutlet weak var myText: UITextView!
    
    var record: Record!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let mRecord = record {
            myImage.image = UIImage(named: mRecord.image.lowercased())
            myText.text = mRecord.description
            myTitle.title = mRecord.name
        }
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
