//
//  Temp.swift
//  CTIS480_Fall2122_HW3
//
//  Created by Syed Ali on 12/5/21.
//  Copyright © 2021 CTIS. All rights reserved.
//

import Foundation

class DataSource {
    var mRecordList: [Record] = []
    var categories: [String] = []
    
    func numbeOfItemsInEachCategory(index: Int) -> Int {
        return itemsInCategory(index: index).count
    }
    
    func numberOfCategories() -> Int {
        return categories.count
    }
    
    func getCategoryLabelAtIndex(index: Int) -> String {
        return categories[index]
    }
    
    // MARK: - Populate Data from files
    func populate(type: String) {
        if type.lowercased() == "json" {
            if let mURL = URL(string: "http://syedali.bilkent.edu.tr/480/data.json") {
                if let data = try? Data(contentsOf: mURL) {
                    
                    // https://www.dotnetperls.com/guard-swift
                    guard let json = try? JSON(data: data) else {
                        print("Error with JSON")
                        return
                    }
                    //print(json)
                    
                    for index in 0..<json["items"].count {
                        let name = json["items"][index]["name"].string!
                        let category = json["items"][index]["category"].string!
                        let description = json["items"][index]["description"].string!
                        let image = json["items"][index]["image"].string!
                        
                        let mRecord = Record(name: name, category: category, description: description, image: image)
                        mRecordList.append(mRecord)
                        
                        if !categories.contains(category) {
                            categories.append(category)
                        }
                    }
                }
                else {
                    print("Data error")
                }
            }
            else {
                
            }
        }else {
            if let mURL = URL (string: "http://syedali.bilkent.edu.tr/480/data.xml"){
                if let data = try? Data(contentsOf: mURL){
                    let xml = SWXMLHash.parse(data)
                    
                    for rec in xml["main"]["item"].all {
                        let mRecord: Record = Record(name: rec["name"].element!.text, category: rec["category"].element!.text, description: rec["description"].element!.text, image: rec["image"].element!.text)
                        
                        mRecordList.append(mRecord)
                        
                        if !categories.contains(mRecord.category) {
                            categories.append(mRecord.category)
                        }
                    }
                }
                else {
                    print("Data error")
                }
            }
        }
    }
    
    

        
        // MARK: - itemsForEachGroup
        func itemsInCategory(index: Int) -> [Record] {
            let item = categories[index]
            
            // See playground6 for Closure
            // http://locomoviles.com/uncategorized/filtering-swift-array-dictionaries-object-property/
            
            let filteredItems = mRecordList.filter { (record: Record) -> Bool in
                return record.category == item
            }
            return filteredItems
        }
    }
