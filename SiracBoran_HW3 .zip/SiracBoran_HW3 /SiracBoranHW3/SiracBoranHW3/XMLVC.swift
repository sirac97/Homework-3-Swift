//
//  XMLVC.swift
//  SiracBoranHW3
//
//  Created by CTIS Student on 14.12.2021.
//  Copyright © 2021 CTIS. All rights reserved.
//

import UIKit


class XMLVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return myDataSource.numberOfCategories()
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "customCell", for: indexPath) as! CustomCollectionViewCell
        let records: [Record] = myDataSource.itemsInCategory(index: indexPath.section)
        let record = records[indexPath.row]
        
        cell.mLabel?.text = record.name
        cell.mImage?.image = UIImage(named: record.image.lowercased())
        
        return cell
    }
    
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return myDataSource.numberOfCategories()
    }
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    let myDataSource = DataSource()
    

   func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
       
       let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "header", for: indexPath) as! CustomCollectionReusableView
       
       if indexPath.section == 0 {
           headerView.headerLabel.text = "Fruits"
       }
       else if indexPath.section == 1 {
           headerView.headerLabel.text = "Trees"
       }
       else if indexPath.section == 2 {
           headerView.headerLabel.text = "Birds"
       }
       else {
           headerView.headerLabel.text = "Flowers"
       }
       
       return headerView
   }
    
    
    
    func getIndexPathForSelectedCell() -> IndexPath? {
        var indexPath: IndexPath?
        
        // Since multiple cells can be selected, we need to check the count
        if collectionView.indexPathsForSelectedItems!.count > 0 {
            indexPath = collectionView.indexPathsForSelectedItems![0] as IndexPath
        }
        
        return indexPath
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detailxml" {
            if let indexPath = getIndexPathForSelectedCell() {
                let record = myDataSource.itemsInCategory(index: indexPath.section)[indexPath.row]
                
                let detailViewController = segue.destination as! DetailVC
                
                detailViewController.record = record
            }
        }
    }
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myDataSource.populate(type: "xml")
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
