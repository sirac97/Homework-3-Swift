//
//  CustomCollectionReusableView.swift
//  SiracBoranHW3
//
//  Created by CTIS Student on 16.12.2021.
//  Copyright © 2021 CTIS. All rights reserved.
//

import UIKit

class CustomCollectionReusableView: UICollectionReusableView {
        
    @IBOutlet weak var headerLabel: UILabel!
}
