//
//  ViewController.swift
//  SiracBoranHW3
//
//  Created by CTIS Student on 14.12.2021.
//  Copyright © 2021 CTIS. All rights reserved.
//

import UIKit

class MainVC: UIViewController {
    
    @IBAction func unwindToMain(_ unwindSegue: UIStoryboardSegue){
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

