//
//  CustomCollectionViewCell.swift
//  SiracBoranHW3
//
//  Created by CTIS Student on 15.12.2021.
//  Copyright © 2021 CTIS. All rights reserved.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var mImage: UIImageView!
    
    
    @IBOutlet weak var mLabel: UILabel!
}
